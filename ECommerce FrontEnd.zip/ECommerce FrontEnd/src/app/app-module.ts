import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { AddProducts } from './components/Admin/add-products/add-products';
import { AdminHome } from './components/Admin/admin-home/admin-home';
import { OrderList } from './components/Admin/order-list/order-list';
import { UserList } from './components/Admin/user-list/user-list';
import { UserHome } from './components/user/user-home/user-home';
import { Cart } from './components/user/cart/cart';
import { Login } from './components/user/login/login';
import { ProductCategory } from './components/user/product-category/product-category';
import { Products } from './components/user/products/products';
import { Profile } from './components/user/profile/profile';
import { Navbar } from './components/shared/navbar/navbar';
import { Register } from './components/user/register/register';

@NgModule({
  declarations: [
    App,
    AddProducts,
    AdminHome,
    OrderList,
    UserList,
    UserHome,
    Cart,
    Login,
    ProductCategory,
    Products,
    Profile,
    Navbar,
    Register
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
     HttpClientModule,
    AppRoutingModule,
     FormsModule,

  ],
  providers: [
    provideBrowserGlobalErrorListeners()
  ],
  bootstrap: [App]
})
export class AppModule { }
