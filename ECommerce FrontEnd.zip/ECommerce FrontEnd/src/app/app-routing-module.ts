import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Login } from './components/user/login/login';
import { UserHome } from './components/user/user-home/user-home';
import { ProductCategory } from './components/user/product-category/product-category';
import { Products } from './components/user/products/products';
import { Cart } from './components/user/cart/cart';
import { Profile } from './components/user/profile/profile';

import { AdminHome } from './components/Admin/admin-home/admin-home';
import { UserList } from './components/Admin/user-list/user-list';
import { OrderList } from './components/Admin/order-list/order-list';
import { AddProducts } from './components/Admin/add-products/add-products';
import { Register } from './components/user/register/register';

const routes: Routes = [ { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'register', component: Register },
  { path: 'login', component: Login },



  // User routes
  { path: 'user-home', component: UserHome},
  { path: 'product-category', component: ProductCategory },
  { path: 'products', component: Products},
   { path: 'products/category/:id', component: Products },
  { path: 'cart', component: Cart },
  { path: 'profile', component: Profile },

  // Admin routes
  { path: 'admin-home', component: AdminHome },
  { path: 'user-list', component: UserList },
  { path: 'order-list', component: OrderList },
  { path: 'add-product', component: AddProducts},

  { path: '**', redirectTo: 'login' }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
