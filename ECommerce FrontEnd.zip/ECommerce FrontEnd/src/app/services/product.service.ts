import { Injectable } from '@angular/core';
import { Product } from '../models/product.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class ProductService {


  private url = 'http://localhost:9090/api/products';

  constructor(private http: HttpClient) {}

  // Get all products
  getAll(): Observable<Product[]> {
    return this.http.get<Product[]>(this.url);
  }

  // Get products by category
  getByCategory(categoryId: number): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.url}/category/${categoryId}`);
  }

  // Add product
  addProduct(product: Product): Observable<Product> {
    return this.http.post<Product>(`${this.url}`,product);
  //  return this.http.post<Product>(this.url, product);
  }


    // private products: Product[] = [];

  // ];

  // // getAll(): Product[] {
  // //   return [...this.products];
  // // }

  // getByCategory(categoryId: number): Product[] {
  //   return this.products.filter(p => p.categoryId === categoryId);
  // }

  // // add(product: Product): void {
  // //   const maxId = this.products.length
  // //     ? Math.max(...this.products.map(p => p.id))
  // //     : 0;
  // //   product.id = maxId + 1;
  // //   this.products.push(product);
  // // }

}
