import { Injectable } from '@angular/core';
import { Order } from '../models/order.model';
import { CartItem } from '../models/cart.model';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class OrderService {

  private url = 'http://localhost:9090/api/orders';

  private ordersSubject = new BehaviorSubject<Order[]>([]);
  orders$: Observable<Order[]> = this.ordersSubject.asObservable();

  constructor(private httpClient: HttpClient) {}

  // ✅ PLACE ORDER (USER)
  placeOrder(
    userId: number,
    productId: number,
    productName: string,
    quantity: number
  ): Observable<Order> {

    return this.httpClient.post<Order>(this.url, {
      userId,
      productId,
      productName,
      quantity
    }).pipe(
      tap((order: Order) => {
        // 🔥 update admin order list instantly
        const updatedOrders = [...this.ordersSubject.value, order];
        this.ordersSubject.next(updatedOrders);
      })
    );
  }

  // ✅ LOAD ALL ORDERS (ADMIN – INITIAL LOAD)
  loadAllOrders(): void {
    this.httpClient.get<Order[]>(this.url).subscribe({
      next: (orders: Order[]) => {
        this.ordersSubject.next(orders);
        
      },
      error: (err) => {
        console.error('Failed to load orders', err);
      }
    });
  }

  // ✅ GET CURRENT ORDERS SNAPSHOT
  getAll(): Order[] {
    return this.ordersSubject.value;
  }

  // ✅ TOTAL ORDERS COUNT
  getTotalOrders(): number {
    return this.ordersSubject.value.length;
  }
}
