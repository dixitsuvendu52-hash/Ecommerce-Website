import { Injectable } from '@angular/core';
import { User } from '../models/user.model';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root',
})
export class UserService {
  // private users: User[] = [
  //  /* { id: 1, name: 'Admin User', email: 'admin@example.com', role: 'ADMIN' },
  //   { id: 2, name: 'John Doe', email: 'john@example.com', role: 'USER' },
  //   { id: 3, name: 'Jane Smith', email: 'jane@example.com', role: 'USER' },*/
  // ];


 url='http://localhost:9090/api/users/';

  constructor(private httpClient:HttpClient) {}

    public getUsers(user:any){
   return this.httpClient.get(`${this.url}`);
  }

 public deleteUser(id: number) {
  return this.httpClient.delete(this.url + id, { responseType: 'text' });
}

  // getAll(): User[] {
  //   return [...this.users];
  // }
}
