import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { User } from '../../../models/user.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-navbar',
  standalone: false,
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',

})
export class Navbar implements OnInit, OnDestroy {

  currentUser: User | null = null;
  private userSub!: Subscription;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}


  ngOnInit(): void {

    this.userSub = this.authService.currentUser$
      .subscribe(user => {
        this.currentUser = user;
        console.log('Navbar user:', user); // 🔍 DEBUG
      });
  }

  ngOnDestroy(): void {
    this.userSub?.unsubscribe();
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  goHome(): void {
    if (!this.currentUser) {
      this.router.navigate(['/login']);
    } else if (this.currentUser.role === 'ADMIN') {
      this.router.navigate(['/admin-home']);
    } else {
      this.router.navigate(['/user-home']);
    }
  }
}

