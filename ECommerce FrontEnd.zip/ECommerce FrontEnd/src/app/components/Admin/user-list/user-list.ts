import { ChangeDetectorRef, Component } from '@angular/core';
import { User } from '../../../models/user.model';
import { UserService } from '../../../services/user.service';

@Component({
  selector: 'app-user-list',
  standalone: false,
  templateUrl: './user-list.html',
  styleUrl: './user-list.css',
})
export class UserList {
  users: User[] = [];
constructor(private userService: UserService, private cd : ChangeDetectorRef) {}

ngOnInit(): void {
  this.loadUsers();
}

loadUsers() {
  this.userService.getUsers(this.users).subscribe((data: any) => {
  //  console.log("API =", data);
   // this.cd.detectChanges();

    this.users = data;
     this.cd.detectChanges();
  });





  }
  deleteUser(id: number) {
  if (confirm("Are you sure you want to delete this user?")) {
    this.userService.deleteUser(id).subscribe(() => {
      alert("User deleted successfully!");
      this.loadUsers();
    });
  }


}}
