import { Component } from '@angular/core';
import { Product } from '../../../models/product.model';
import { ProductService } from '../../../services/product.service';
import { CategoryService } from '../../../services/category.service';
import { Category}from'../../../models/category.model';
@Component({
  selector: 'app-add-products',
  standalone: false,
  templateUrl: './add-products.html',
  styleUrl: './add-products.css',
})
export class AddProducts {
   product: Partial<Product> = {
    name: '',
    price: 0,
    categoryId: 1,
    description: '',
    imageUrl: 'https://via.placeholder.com/150'
  };

  categories: Category[] = [];

  constructor(
    private productService: ProductService,
    private categoryService: CategoryService
  ) {
    this.categories = this.categoryService.getAll();
  }

  save() {
    if (!this.product.name || !this.product.price || !this.product.categoryId) {
      alert('Name, price and category are required.');
      return;
    }
  
    this.productService.addProduct(this.product as Product).subscribe({
      next: (res) => {
        console.log('Backend response:', res);
        alert('Product added successfully!');
  
        // reset form AFTER backend success
        this.product = {
          name: '',
          price: 0,
          categoryId: this.categories[0]?.id || 1,
          description: '',
          imageUrl: 'https://via.placeholder.com/150'
        };
      },
      error: (err) => {
        console.error('Backend error:', err);
        alert('Failed to add product');
      }
    });
  }}
