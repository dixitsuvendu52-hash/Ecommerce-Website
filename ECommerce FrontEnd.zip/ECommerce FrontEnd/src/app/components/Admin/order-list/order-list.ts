import { ChangeDetectorRef,Component,OnInit } from '@angular/core';
import { Order } from '../../../models/order.model';
import { OrderService } from '../../../services/order.service';

@Component({
  selector: 'app-order-list',
  standalone: false,
  templateUrl: './order-list.html',
  styleUrl: './order-list.css',
})
export class OrderList implements OnInit{
orders: Order[] = [];   // ✅ ADD / CONFIRM THIS LINE

  constructor(private orderService: OrderService,private cd : ChangeDetectorRef) {}

  ngOnInit(): void {
    this.orderService.loadAllOrders();
    console.log('Admin OrderList loaded');
   // this.cd.detectChanges();
    this.orderService.orders$.subscribe({
      next: (orders: Order[]) => {
         console.log('Orders from service:', orders);


        this.orders = orders;
            this.cd.detectChanges();

      },
      error: (err: any) => {
        console.error(err);
      }
    });
  }
}
