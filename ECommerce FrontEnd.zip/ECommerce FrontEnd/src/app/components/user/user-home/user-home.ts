import { Component } from '@angular/core';
import { AuthService } from '../../../services/auth.service';
import { User } from '../../../models/user.model';
@Component({
  selector: 'app-user-home',
  standalone: false,
  templateUrl: './user-home.html',
  styleUrl: './user-home.css',
})
export class UserHome {
 user: User | null = null;

  constructor(private authService: AuthService) {
    this.user = this.authService.getCurrentUser();
  }
}
