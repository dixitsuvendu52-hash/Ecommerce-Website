import { Component,OnInit } from '@angular/core';
import { CartItem } from '../../../models/cart.model';
import { CartService } from '../../../services/cart.service';
import { AuthService } from '../../../services/auth.service';
import { OrderService } from '../../../services/order.service';
import { User } from '../../../models/user.model';


@Component({
  selector: 'app-cart',
  standalone: false,
  templateUrl: './cart.html',
  styleUrl: './cart.css',
})
export class Cart implements OnInit {

  items: CartItem[] = [];
  total = 0;

  constructor(
    private cartService: CartService,
    private authService: AuthService,
    private orderService: OrderService
  ) {}

  ngOnInit(): void {
    this.loadCart();
  }

  loadCart(): void {
    this.items = this.cartService.getItems();
    this.total = this.cartService.getTotal();
  }

  removeItem(id?: number): void {
    if (!id) return;
    this.cartService.removeFromCart(id);
    this.loadCart();
  }
checkout(): void {
  const user: User | null = this.authService.getCurrentUser();

  if (!user) {
    alert('Please login first.');
    return;
  }

  if (!this.items.length) {
    alert('Your cart is empty.');
    return;
  }

  // 🔥 PLACE ONE ORDER PER ITEM
  this.items.forEach(item => {
  this.orderService.placeOrder(
    user.id,
    item.product.id,
    item.product.name,
    item.quantity
  ).subscribe();
});

  alert('Order placed successfully');

  // ✅ Clear cart
  this.cartService.clearCart();
  this.items = [];
  this.total = 0;
}
}
