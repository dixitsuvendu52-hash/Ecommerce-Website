import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
 email = '';
  password = '';
  error = '';

  user = new User();
  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
    this.error = '';
    if (!this.user.email || !this.user.password) {
      this.error = 'Email and password are required.';
      return;
    }

    this.authService.loginUser(this.user).subscribe(
      (data:any)=>
      {
        if(data!=null){
          if (data.role === 'ADMIN') {
        this.router.navigate(['/admin-home']);
      } else {
        this.router.navigate(['/user-home']);
      }

        // alert("login success");
        //  this.router.navigate(['user-home']);
        }else
          alert("not success");
      }
    );
  /*  if (success) {
      if (this.email.startsWith('admin')) {
        this.router.navigate(['/admin-home']);
      } else {
        this.router.navigate(['/user-home']);
      }
    } else {
      this.error = 'Invalid credentials';
    }*/
  }
}
