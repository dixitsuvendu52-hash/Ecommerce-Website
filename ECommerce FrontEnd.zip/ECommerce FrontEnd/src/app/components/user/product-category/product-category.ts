import { Component,OnInit } from '@angular/core';
import { Category } from '../../../models/category.model';
import { CategoryService } from '../../../services/category.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-category',
  standalone: false,
  templateUrl: './product-category.html',
  styleUrl: './product-category.css',
})
export class ProductCategory implements OnInit {
categories: Category[] = [];

  constructor(private categoryService: CategoryService, private router: Router) {}

  ngOnInit(): void {
    this.categories = this.categoryService.getAll();
  }

 viewCategory(category: Category): void {
  this.router.navigate(['/products/category', category.id]);
}
}
