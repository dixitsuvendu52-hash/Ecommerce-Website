import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { NgForm } from '@angular/forms';
import { User } from '../../../models/user.model';


@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.html',
  styleUrl: './register.css',
})
export class Register {
// user = {
//     username: '',
//     email: '',
//     password: '',
//     phone: '',
//     address: '',
//     role: 'USER'
//   };

  user = new User();
  error: string = '';

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  onSubmit(form: NgForm) {

    this.error = '';


    if (form.invalid) {
      this.error = "All fields are required.";
      return;
    }

    this.authService.registerUser(this.user).subscribe({
      next: (data: any) => {
        alert("✅ Registered Successfully");

        form.reset();       
        this.router.navigate(['/auth/login']);
      },

      error: (err) => {
        console.error(err);
        this.error = " Registration failed. Try again.";
      }
    });
  }
}
