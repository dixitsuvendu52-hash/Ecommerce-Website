import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../../../models/product.model';
import { ProductService } from '../../../services/product.service';
import { CartService } from '../../../services/cart.service';

@Component({
  selector: 'app-products',
  standalone: false,
  templateUrl: './products.html',
  styleUrl: './products.css',
})
export class Products implements OnInit{
products: Product[] = [];
  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private cartService: CartService,
    private cd:ChangeDetectorRef
  ) {}

 ngOnInit(): void {
    // 🔥 IMPORTANT: listen to route changes
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
       console.log('ROUTE PARAM ID:', id); 

      if (id !== null) {
        // Load products by category
        this.productService.getByCategory(+id).subscribe({
          next: data => {
            this.products = data;
            this.cd.detectChanges();
            console.log('Products by category:', data);
          },
        error: (err) => console.error(err)
      });
    } else {
      this.productService.getAll().subscribe({
        next: (data) => {
          this.products = data;
          this.cd.detectChanges();
          console.log('All products:', data);
        },
        error: (err) => console.error(err)
      });
    }
  })
}
  /*addToCart(product: Product): void {
    this.cartService.addToCart(product);
  }*/





  addToCart(product: Product) {
    this.cartService.addToCart(product);
    alert('Added to cart');
  }
}
