export type UserRole = 'USER' | 'ADMIN';
export class User {
  id: number;
  username: string;
  email: string;
  role: UserRole;
  password:string;
  phone:string;
  address:string;

  constructor()
  {
    this.id=12;
    this.username="";
    this.address="";
    this.phone="";
    this.email="";
    this.password="";
    this.role='USER';
  }
}
